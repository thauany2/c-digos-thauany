# Escreva um programa que pede ao usuário dois números e exiba no final a soma deles:
# OUTPUT ESPERADO:

# Digite um número: 10
# Digite outro número: 30
# A soma entre 10 e 30 é: 40


# ------------------------------------------ ESCREVA SEU CÓDIGO ABAIXO -----------------------------------------------------------

